﻿/********************************************************************************
 * Traits Diagnostics Console 
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitDiagnosticsCoreConsole
{
    using DiagnosticsQuickStart.Business;
    using System;
    using System.Collections.Generic;
    using TraitsQuickStart.Business;
    using TraitsQuickStart.Data;
    using TraitsQuickStart.Features.Pipelines.Business;
    using TraitsQuickStart.Features.Pipelines.Data;
    using TraitsQuickStart.ReflectionByDefinition;

    class Program
    {
        static void Main(string[] args)
        {
            // Make it look like a main frame (Thanks Martina Welander for inspiration)
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WindowWidth = 160;
            Console.WriteLine("Traits Diagnostics .NET Core Console");

            // TO DO: Should allow for override of this path
            var providerRootPath = "..\\..\\..\\..\\..\\data\\Providers";
            var reflectionDefinitionPath = "..\\..\\..\\..\\..\\data\\Reflections";
            var defaultTraitsFilePath = "..\\..\\..\\..\\..\\data\\defaulttraits.json";
            var defaultTraitsPipelineFileFullPath = "..\\..\\..\\..\\..\\data\\pipelines\\defaulttraitspipeline.json";

            var defaultReflectionDefinitionEnabledPipelineFileFullPath = "..\\..\\..\\..\\..\\data\\pipelines\\defaultreflectiondefinitionenabledpipeline.json";
            var defaultReflectionDefinitionName = "PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE";

            var status = new ConsoleEventLog();

            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            var reflectionManager = new ReflectionManager()
            {
                ProviderRootFolder = providerRootPath,
                ReflectionDefinitionFolder = reflectionDefinitionPath
            };

            int choice = -1;
            while (choice != -99)
            {
                Console.WriteLine("\r\n\r\n");
                Console.WriteLine("Choose a task by typing the number (or type -99 to QUIT) and pressing enter:");
                Console.WriteLine("1 - Create a traits file using BaseTraits");
                Console.WriteLine("2 - Validate a traits file");
                Console.WriteLine("3 - Create reflection definitions");
                Console.WriteLine("4 - Validate a reflection definition");
                Console.WriteLine("5 - Create a traits pipeline");
                Console.WriteLine("6 - Validate a traits pipeline");
                Console.WriteLine("7 - Execute a traits pipeline");
                Console.WriteLine("8 - Create a reflection definition enabled pipeline");
                Console.WriteLine("9 - Validate a reflection definition enabled pipeline");
                Console.WriteLine("10 - Execute a reflection definition enabled pipeline");

                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case -99: // Exit value
                        break;
                    case 1:     // 1 - Create a language detection traits file

                        DoCreateTraitsFile(defaultTraitsFilePath, status);
                        break;

                    case 2:

                        #region 2 - Validate a language detection traits file

                        #endregion

                        break;

                    case 3:     // 3 - Create reflection definitions

                        DoCreateReflectionDefinitions(providerRootPath, reflectionDefinitionPath);

                        break;

                    case 4:

                        #region 4 - Validate a reflection definition

                        Console.WriteLine("Please enter the reflection definition name: (Press ENTER for PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE)");
                        var reflectionDefinitionName = Console.ReadLine();
                        if (string.IsNullOrEmpty(reflectionDefinitionName)) reflectionDefinitionName = defaultReflectionDefinitionName;

                        var loadedReflectionDefinition = reflectionManager.LoadReflectionDefinition(reflectionDefinitionName);
                        if (loadedReflectionDefinition == null) throw new NullReferenceException("ERROR: cannot load " + reflectionDefinitionName);

                        Console.WriteLine("Loaded assembly " + reflectionDefinitionName + " successfully.");
                        Console.WriteLine(string.Format("     - AssemblyName: {0}\r\n     - AssemblyPath: {1}\r\n     - TypeName: {2}", loadedReflectionDefinition.AssemblyName, loadedReflectionDefinition.AssemblyPath, loadedReflectionDefinition.TypeName));

                        #endregion

                        break;

                    case 5:     // 5- Create a traits pipeline

                        DoCreateTraitsPipeline(providerRootPath, defaultTraitsFilePath, defaultTraitsPipelineFileFullPath, status);

                        break;

                    case 6:
                        #region 6 - Validate a traits pipeline
                        #endregion
                        break;

                    case 7:     // 7 - Execute a traits pipeline

                        DoExecuteTraitsPipeline(providerRootPath, defaultTraitsFilePath, defaultTraitsPipelineFileFullPath, status);
                        break;

                    case 8:     // 8 - Create a reflection definition enabled pipeline

                        DoCreateReflectionDefinitionEnabledPipeline(providerRootPath, reflectionDefinitionPath, defaultTraitsFilePath, defaultReflectionDefinitionEnabledPipelineFileFullPath, status);

                        break;

                    case 9:

                        #region 9 - Validate a reflection definition enabled pipeline

                        #endregion

                        Console.WriteLine("Invalid Choice - 9 !!!");
                        break;

                    case 10:    // 10 - Execute a reflection definition enabled language detection pipeline

                        DoExecuteReflectionDefinitionEnabledPipeline(providerRootPath, reflectionDefinitionPath, defaultTraitsFilePath, defaultReflectionDefinitionEnabledPipelineFileFullPath, status);
                        break;

                    default:
                        Console.WriteLine("Invalid Choice - " + choice + " !!!");
                        break;
                }
            }
        }

        #region Traits Related 

        static bool DoCreateTraitsFile(string defaultTraitsFilePath, IEventLog status)
        {
            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            Console.WriteLine("Please enter the full path (including filename) to the traits file you wish to create: (Press ENTER for default)");
            var newTraitsFileFullPath = Console.ReadLine();
            if (string.IsNullOrEmpty(newTraitsFileFullPath)) newTraitsFileFullPath = defaultTraitsFilePath;

            var traits = new BaseTraits
            {
                TraitPairs = new Dictionary<string, string>
                {
                    { "PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE", "TraitsQuickStart.Features.Pipelines.StorageProviders.dll,TraitsQuickStart.Features.Pipelines.StorageProviders.FileTraitsPipelineProvider," },
                    { "PROVIDER_PIPELINE_STORAGE_PROVIDER_STRING", "TraitsQuickStart.Features.Pipelines.StorageProviders.dll,TraitsQuickStart.Features.Pipelines.StorageProviders.StringTraitsPipelineProvider," }
                }
            };

            if (traitsManager.SaveTraits("FILE", newTraitsFileFullPath, traits) == false)
            {
                Console.WriteLine("ERROR: Creating traits file failed for: " + newTraitsFileFullPath);
                return false;
            }
            else
            {
                Console.WriteLine("SUCCESS: Traits file created at: " + newTraitsFileFullPath);
                return true;
            }
        }

        #endregion

        #region Traits Pipeline Related

        static bool DoCreateTraitsPipeline(string providerRootPath, string defaultTraitsFilePath, string defaultTraitsPipelineFileFullPath, IEventLog status)
        {
            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            Console.WriteLine("Please enter the full path (including filename) to the traits file: (Press ENTER for default)");
            var traitsFileFullPath = Console.ReadLine();
            if (string.IsNullOrEmpty(traitsFileFullPath)) traitsFileFullPath = defaultTraitsFilePath;

            Console.WriteLine("Please enter the full path (including filename) to the traits pipeline file you wish to create:");
            var newTraitsPipelineFileFullPath = Console.ReadLine();
            if (string.IsNullOrEmpty(newTraitsPipelineFileFullPath)) newTraitsPipelineFileFullPath = defaultTraitsPipelineFileFullPath;

            var traits = traitsManager.GetTraits("FILE", traitsFileFullPath);

            var traitsPipeline = new TraitsPipeline()
            {
                ErrorMode = "STOP_ON_ERROR",
                PipelineExecutionMode = "ALL_MATCHING"
            };
            traitsPipeline.PipelineSteps.Add(new TraitsPipelineStep()
            {
                ProviderName = "TEST"
            });

            var traitsPipelineManager = new TraitsPipelineManager()
            {
                Status = status,
                Pipeline = traitsPipeline,
                ProviderRootPath = providerRootPath,
                Traits = traits
            };

            if (traitsPipelineManager.SaveTraitsPipeline("SAMPLE", "FILE", newTraitsPipelineFileFullPath, null) == false)
            {
                Console.WriteLine("ERROR: Creating traits file failed for: " + newTraitsPipelineFileFullPath);
                return false;
            }
            else
            {
                Console.WriteLine("SUCCESS: Traits file created at: " + newTraitsPipelineFileFullPath);
                return true;
            }
        }

        static bool DoExecuteTraitsPipeline(string providerRootPath, string defaultTraitsFilePath, string defaultTraitsPipelineFileFullPath, IEventLog status)
        {
            Console.WriteLine("Please enter the full path (including filename) to the traits pipeline file you wish to create: (Press ENTER for for default location)");
            var loadTraitsPipelineFileFullPath = Console.ReadLine();
            if (string.IsNullOrEmpty(loadTraitsPipelineFileFullPath)) loadTraitsPipelineFileFullPath = defaultTraitsPipelineFileFullPath;

            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            var traits = traitsManager.GetTraits("FILE", defaultTraitsFilePath);

            var traitsPipelineManager = new TraitsPipelineManager()
            {
                Status = status,
                ProviderRootPath = providerRootPath,
                Traits = traits
            };

            // TO DO: Derived class will load the specific pipeline type
            //var traitsPipeline = traitsPipelineManager.LoadTraitsPipeline(string.Empty, "FILE", defaultTraitsPipelineFileFullPath, null);

            // TO DO: Derived will execute the specific pipeline type
            traitsPipelineManager.ExecuteTraitsPipeline();

            return false;
        }

        #endregion

        #region Reflection Definition Related

        static bool DoCreateReflectionDefinitions(string providerRootPath, string reflectionDefinitionPath)
        {
            var reflectionManager = new ReflectionManager()
            {
                ProviderRootFolder = providerRootPath,
                ReflectionDefinitionFolder = reflectionDefinitionPath
            };

            #region Traits Related

            var reflectionDefinition = new ReflectionDefinition()
            {
                AssemblyName = "TraitsQuickStart.Features.Pipelines.StorageProviders",
                AssemblyPath = "{PROVIDER_ROOT_PATH}",
                TypeName = "TraitsQuickStart.Features.Pipelines.StorageProviders.FileTraitsPipelineProvider",
                UseActivator = false
            };
            if (reflectionManager.CreateReflectionDefinition("PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE", reflectionDefinition) == false) return false;

            reflectionDefinition = new ReflectionDefinition()
            {
                AssemblyName = "TraitsQuickStart.Features.Pipelines.StorageProviders",
                AssemblyPath = "{PROVIDER_ROOT_PATH}",
                TypeName = "TraitsQuickStart.Features.Pipelines.StorageProviders.StringTraitsPipelineProvider",
                UseActivator = false
            };
            if (reflectionManager.CreateReflectionDefinition("PROVIDER_PIPELINE_STORAGE_PROVIDER_STRING", reflectionDefinition) == false) return false;

            #endregion

            return true;
        }

        static bool DoValidateReflectionDefinition(string providerRootPath, string reflectionDefinitionPath, string defaultReflectionDefinitionName)
        {
            var reflectionManager = new ReflectionManager()
            {
                ProviderRootFolder = providerRootPath,
                ReflectionDefinitionFolder = reflectionDefinitionPath
            };

            Console.WriteLine("Please enter the reflection definition name: (Press ENTER for PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE)");
            var reflectionDefinitionName = Console.ReadLine();
            if (string.IsNullOrEmpty(reflectionDefinitionName)) reflectionDefinitionName = defaultReflectionDefinitionName;

            var loadedReflectionDefinition = reflectionManager.LoadReflectionDefinition(reflectionDefinitionName);
            if (loadedReflectionDefinition == null) throw new NullReferenceException("ERROR: cannot load " + reflectionDefinitionName);

            Console.WriteLine("Loaded assembly " + reflectionDefinitionName + " successfully.");
            Console.WriteLine(string.Format("     - AssemblyName: {0}\r\n     - AssemblyPath: {1}\r\n     - TypeName: {2}", loadedReflectionDefinition.AssemblyName, loadedReflectionDefinition.AssemblyPath, loadedReflectionDefinition.TypeName));

            return true;
        }

        #endregion

        #region Reflection Definition Enabled Pipeline Related

        static bool DoCreateReflectionDefinitionEnabledPipeline(string providerRootPath, string reflectionDefinitionPath, string defaultTraitsFilePath, string defaultReflectionDefinitionEnabledPipelineFileFullPath, IEventLog status)
        {
            Console.WriteLine("Please enter the full path (including filename) to the reflection definition pipeline file you wish to create: (Press ENTER for for default location)");
            var newReflectionDefinitionEnabledPipelineFileFullPath = Console.ReadLine();
            if (string.IsNullOrEmpty(newReflectionDefinitionEnabledPipelineFileFullPath)) newReflectionDefinitionEnabledPipelineFileFullPath = defaultReflectionDefinitionEnabledPipelineFileFullPath;

            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            var traits = traitsManager.GetTraits("FILE", defaultTraitsFilePath);

            var reflectionDefinitionEnabledTraitsPipeline = new TraitsPipeline()
            {
                ErrorMode = "STOP_ON_ERROR",
                PipelineExecutionMode = "ALL_MATCHING"
            };
            reflectionDefinitionEnabledTraitsPipeline.PipelineSteps.Add(new TraitsPipelineStep()
            {
                ProviderName = "TEST"
            });

            var reflectionDefinitionTraitsPipelineManager = new ReflectionDefinitionEnabledTraitsPipelineManager()
            {
                Status = status,
                Pipeline = reflectionDefinitionEnabledTraitsPipeline,
                ReflectionDefinitionFolder = reflectionDefinitionPath,
                ProviderRootPath = providerRootPath,
                Traits = traits
            };

            if (reflectionDefinitionTraitsPipelineManager.SaveTraitsPipeline("SAMPLE", "FILE", newReflectionDefinitionEnabledPipelineFileFullPath, null) == false)
            {
                Console.WriteLine("ERROR: Creating pipeline file failed for: " + newReflectionDefinitionEnabledPipelineFileFullPath);
                return false;
            }
            else
            {
                Console.WriteLine("SUCCESS: Pipeline file created at: " + newReflectionDefinitionEnabledPipelineFileFullPath);
                return true;
            }
        }

        static bool DoExecuteReflectionDefinitionEnabledPipeline(string providerRootPath, string reflectionDefinitionPath, string defaultTraitsFilePath, string defaultReflectionDefinitionEnabledPipelineFileFullPath, IEventLog status)
        {
            Console.WriteLine("Please enter the full path (including filename) to the reflection definition pipeline file you wish to create: (Press ENTER for for default location)");
            var loadReflectionDefinitionEnabledPipelineFileFullPath = Console.ReadLine();
            if (string.IsNullOrEmpty(loadReflectionDefinitionEnabledPipelineFileFullPath)) loadReflectionDefinitionEnabledPipelineFileFullPath = defaultReflectionDefinitionEnabledPipelineFileFullPath;

            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            var traits = traitsManager.GetTraits("FILE", defaultTraitsFilePath);

            var reflectionDefinitionTraitsPipelineManager = new ReflectionDefinitionEnabledTraitsPipelineManager()
            {
                Status = status,
                ReflectionDefinitionFolder = reflectionDefinitionPath,
                ProviderRootPath = providerRootPath,
                Traits = traits
            };

            // TO DO: The specific implementation would do its own loading of traits pipeline
            //var reflectionDefinitionEnabledTraitsPipeline = reflectionDefinitionTraitsPipelineManager.LoadTraitsPipeline(string.Empty, "FILE", defaultReflectionDefinitionEnabledPipelineFileFullPath, null);

            // TO DO: The specific implementation would do its own execution of traits pipeline
            // reflectionDefinitionTraitsPipelineManager.ExecuteTraitsPipeline();

            return false;
        }

        #endregion
    }
}
