﻿/********************************************************************************
 * Traits Diagnostics Console 
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitDiagnosticsCoreConsole
{
    using DiagnosticsQuickStart.Business;
    using System;
    using System.Collections.Generic;
    using TraitsQuickStart.Business;
    using TraitsQuickStart.Data;
    using TraitsQuickStart.Features.Pipelines.Business;
    using TraitsQuickStart.Features.Pipelines.Data;
    using TraitsQuickStart.ReflectionByDefinition;

    class Program
    {
        static void Main(string[] args)
        {
            // Make it look like a main frame (Thanks Martina Welander for inspiration)
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WindowWidth = 160;
            Console.WriteLine("Traits Diagnostics .NET Core Console");

            // TO DO: Should allow for override of this path
            var providerRootPath = "..\\..\\..\\..\\..\\data\\Providers";
            var reflectionDefinitionPath = "..\\..\\..\\..\\..\\data\\Reflections";
            var defaultTraitsFilePath = "..\\..\\..\\..\\..\\data\\defaulttraits.json";
            var defaultTraitsPipelineFileFullPath = "..\\..\\..\\..\\..\\data\\pipelines\\defaulttraitspipeline.json";

            var defaultReflectionDefinitionEnabledPipelineFileFullPath = "..\\..\\..\\..\\..\\data\\pipelines\\defaultreflectiondefinitionenabledpipeline.json";
            var defaultReflectionDefinitionName = "PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE";

            var status = new ConsoleEventLog();

            var traitsManager = new TraitsManager()
            {
                Status = status
            };

            var reflectionManager = new ReflectionManager()
            {
                ProviderRootFolder = providerRootPath,
                ReflectionDefinitionFolder = reflectionDefinitionPath
            };

            ITraits traits = null;

            int choice = -1;
            while (choice != -99)
            {
                Console.WriteLine("\r\n\r\n");
                Console.WriteLine("Choose a task by typing the number (or type -99 to QUIT) and pressing enter:");
                Console.WriteLine("1 - Create a traits file using BaseTraits");
                Console.WriteLine("2 - Validate a traits file");
                Console.WriteLine("3 - Create reflection definitions");
                Console.WriteLine("4 - Validate a reflection definition");
                Console.WriteLine("5 - Create a traits pipeline");
                Console.WriteLine("6 - Validate a traits pipeline");
                Console.WriteLine("7 - Execute a traits pipeline");
                Console.WriteLine("8 - Create a reflection definition enabled pipeline");
                Console.WriteLine("9 - Validate a reflection definition enabled pipeline");
                Console.WriteLine("10 - Execute a reflection definition enabled pipeline");

                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case -99: // Exit value
                        break;
                    case 1:

                        #region 1 - Create a sample traits file using BaseTraits

                        Console.WriteLine("Please enter the full path (including filename) to the traits file you wish to create: (Press ENTER for default)");
                        var newTraitsFileFullPath = Console.ReadLine();
                        if (string.IsNullOrEmpty(newTraitsFileFullPath)) newTraitsFileFullPath = defaultTraitsFilePath;

                        traits = new BaseTraits
                        {
                            TraitPairs = new Dictionary<string, string>
                            {
                                { "PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE", "TraitsQuickStart.Features.Pipelines.StorageProviders.dll,TraitsQuickStart.Features.Pipelines.StorageProviders.FileTraitsPipelineProvider," },
                                { "PROVIDER_PIPELINE_STORAGE_PROVIDER_STRING", "TraitsQuickStart.Features.Pipelines.StorageProviders.dll,TraitsQuickStart.Features.Pipelines.StorageProviders.StringTraitsPipelineProvider," }
                            }
                        };

                        if (traitsManager.SaveTraits("FILE", newTraitsFileFullPath, traits) == false)
                        {
                            Console.WriteLine("ERROR: Creating traits file failed for: " + newTraitsFileFullPath);
                        }
                        else
                        {
                            Console.WriteLine("SUCCESS: Traits file created at: " + newTraitsFileFullPath);
                        }

                        #endregion

                        break;

                    case 2: // Validate a traits file
                        throw new Exception("Invalid Choice!!!");

                    case 3:

                        #region 3 - Create reflection definitions

                        var reflectionDefinition = new ReflectionDefinition()
                        {
                            AssemblyName = "TraitsQuickStart.Features.Pipelines.StorageProviders",
                            AssemblyPath = providerRootPath,
                            TypeName = "TraitsQuickStart.Features.Pipelines.StorageProviders.FileTraitsPipelineProvider",
                            UseActivator = false
                        };
                        reflectionManager.CreateReflectionDefinition("PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE", reflectionDefinition);

                        reflectionDefinition = new ReflectionDefinition()
                        {
                            AssemblyName = "TraitsQuickStart.Features.Pipelines.StorageProviders",
                            AssemblyPath = providerRootPath,
                            TypeName = "TraitsQuickStart.Features.Pipelines.StorageProviders.StringTraitsPipelineProvider",
                            UseActivator = false
                        };
                        reflectionManager.CreateReflectionDefinition("PROVIDER_PIPELINE_STORAGE_PROVIDER_STRING", reflectionDefinition);

                        #endregion

                        break;

                    case 4:

                        #region 4 - Validate a reflection definition

                        Console.WriteLine("Please enter the reflection definition name: (Press ENTER for PROVIDER_PIPELINE_STORAGE_PROVIDER_FILE)");
                        var reflectionDefinitionName = Console.ReadLine();
                        if (string.IsNullOrEmpty(reflectionDefinitionName)) reflectionDefinitionName = defaultReflectionDefinitionName;

                        var loadedReflectionDefinition = reflectionManager.LoadReflectionDefinition(reflectionDefinitionName);
                        if (loadedReflectionDefinition == null) throw new NullReferenceException("ERROR: cannot load " + reflectionDefinitionName);

                        Console.WriteLine("Loaded assembly " + reflectionDefinitionName + " successfully.");
                        Console.WriteLine(string.Format("     - AssemblyName: {0}\r\n     - AssemblyPath: {1}\r\n     - TypeName: {2}", loadedReflectionDefinition.AssemblyName, loadedReflectionDefinition.AssemblyPath, loadedReflectionDefinition.TypeName));

                        #endregion

                        break;

                    case 5:

                        #region 5 - Create a traits pipeline

                        Console.WriteLine("Please enter the full path (including filename) to the traits file: (Press ENTER for default)");
                        var traitsFileFullPath = Console.ReadLine();
                        if (string.IsNullOrEmpty(traitsFileFullPath)) traitsFileFullPath = defaultTraitsFilePath;

                        Console.WriteLine("Please enter the full path (including filename) to the traits pipeline file you wish to create:");
                        var newTraitsPipelineFileFullPath = Console.ReadLine();
                        if (string.IsNullOrEmpty(newTraitsPipelineFileFullPath)) newTraitsPipelineFileFullPath = defaultTraitsPipelineFileFullPath;

                        traits = traitsManager.GetTraits("FILE", traitsFileFullPath);

                        var traitsPipeline = new TraitsPipeline()
                        {
                            ErrorMode = "STOP_ON_ERROR",
                            PipelineExecutionMode = "ALL_MATCHING"                            
                        };
                        traitsPipeline.PipelineSteps.Add(new TraitsPipelineStep()
                        {
                            ProviderName = "TEST"
                        });

                        var traitsPipelineManager = new TraitsPipelineManager()
                        {
                            Status = status,
                            Pipeline = traitsPipeline,
                            ProviderRootPath = providerRootPath,
                            Traits = traits
                        };

                        if (traitsPipelineManager.SaveTraitsPipeline("SAMPLE", "FILE", newTraitsPipelineFileFullPath, null) == false)
                        {
                            Console.WriteLine("ERROR: Creating traits file failed for: " + newTraitsPipelineFileFullPath);
                        }
                        else
                        {
                            Console.WriteLine("SUCCESS: Traits file created at: " + newTraitsPipelineFileFullPath);
                        }

                        #endregion

                        break;

                    case 6:
                        #region 6 - Validate a traits pipeline
                        #endregion
                        break;

                    case 7:
                        #region 7 - Execute a traits pipeline

                        #endregion

                        break;
                    case 8: // Create a sample pipeline using reflection definition

                        #region 8 - Create a reflection definition enabled pipeline

                        Console.WriteLine("Please enter the full path (including filename) to the reflection definition pipeline file you wish to create: (Press ENTER for for default location)");
                        var newReflectionDefinitionEnabledPipelineFileFullPath = Console.ReadLine();
                        if (string.IsNullOrEmpty(newReflectionDefinitionEnabledPipelineFileFullPath)) newReflectionDefinitionEnabledPipelineFileFullPath = defaultReflectionDefinitionEnabledPipelineFileFullPath;

                        var reflectionDefinitionEnabledTraitsPipeline = new TraitsPipeline()
                        {
                            ErrorMode = "STOP_ON_ERROR",
                            PipelineExecutionMode = "ALL_MATCHING"
                        };
                        reflectionDefinitionEnabledTraitsPipeline.PipelineSteps.Add(new TraitsPipelineStep()
                        {
                            ProviderName = "TEST"
                        });

                        var reflectionDefinitionTraitsPipelineManager = new ReflectionDefinitionEnabledTraitsPipelineManager()
                        {
                            Status = status,
                            Pipeline = reflectionDefinitionEnabledTraitsPipeline,
                            ReflectionDefinitionFolder = reflectionDefinitionPath,
                            ProviderRootPath = providerRootPath,
                            Traits = traits
                        };

                        if (reflectionDefinitionTraitsPipelineManager.SaveTraitsPipeline("SAMPLE", "FILE", newReflectionDefinitionEnabledPipelineFileFullPath, null) == false)
                        {
                            Console.WriteLine("ERROR: Creating pipeline file failed for: " + newReflectionDefinitionEnabledPipelineFileFullPath);
                        }
                        else
                        {
                            Console.WriteLine("SUCCESS: Pipeline file created at: " + newReflectionDefinitionEnabledPipelineFileFullPath);
                        }

                        #endregion

                        break;

                    case 9:

                        #region 9 - Validate a reflection definition enabled pipeline

                        #endregion

                        Console.WriteLine("Invalid Choice - 9 !!!");
                        break;

                    case 10:

                        #region 10 - Execute a reflection definition enabled pipeline

                        #endregion  

                        Console.WriteLine("Invalid Choice - 10 !!!");
                        break;

                    default:
                        Console.WriteLine("Invalid Choice - " + choice + " !!!");
                        break;
                }
            }
        }
    }
}
