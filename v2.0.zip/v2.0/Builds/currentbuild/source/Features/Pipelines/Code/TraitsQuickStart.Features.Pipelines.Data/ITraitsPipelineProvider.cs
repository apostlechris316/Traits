﻿/********************************************************************************
 * Traits Enabled Pipeline Library
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitsQuickStart.Features.Pipelines.Data
{
    using System.Collections.Generic;

    /// <summary>
    /// Interface Implemented all Traits Providers
    /// </summary>
    public interface ITraitsPipelineProvider
    {
        /// <summary>
        /// Settings that affect the behavior of the provider
        /// </summary>
        Dictionary<string, string> ProviderSettings { get; set; }
    }
}
