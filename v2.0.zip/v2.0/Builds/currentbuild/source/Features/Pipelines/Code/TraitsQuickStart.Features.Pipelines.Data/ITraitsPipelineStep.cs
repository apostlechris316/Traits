﻿/********************************************************************************
 * Traits Enabled Pipeline Library
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/


namespace TraitsQuickStart.Features.Pipelines.Data
{
    /// <summary>
    /// Interface implemented by all Traits Pipeline steps
    /// </summary>
    public interface ITraitsPipelineStep
    {
        /// <summary>
        /// Name of provider to execute.
        /// </summary>
        string ProviderName { get; set; }

        /// <summary>
        /// Provider to execute
        /// </summary>
        ITraitsPipelineProvider Provider { get; set; }
    }
}
