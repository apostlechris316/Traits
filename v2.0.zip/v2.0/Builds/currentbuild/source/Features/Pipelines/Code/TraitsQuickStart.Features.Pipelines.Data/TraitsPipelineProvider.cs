﻿/********************************************************************************
 * Traits Enabled Pipeline Library
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitsQuickStart.Features.Pipelines.Data
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    /// <summary>
    /// Pipeline of providers executed based on a given set of rules
    /// </summary>
    [DataContract]
    /// TraitsPipelineStep
    public class TraitsPipelineProvider : ITraitsPipelineProvider
    {
        /// <summary>
        /// Settings that affect the behavior of the provider
        /// </summary>
        [DataMember]
        public Dictionary<string, string> ProviderSettings { get; set; } = new Dictionary<string, string>();
    }
}
