﻿/********************************************************************************
 * Traits Enabled Pipeline Library
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitsQuickStart.Features.Pipelines.Data
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    /// <summary>
    /// Step within a Pipeline of providers executed based on a given set of rules
    /// </summary>
    [DataContract]
    public class TraitsPipelineStep : ITraitsPipelineStep
    {
        /// <summary>
        /// Name of provider to execute.
        /// </summary>
        [DataMember]
        public string ProviderName { get; set; }

        /// <summary>
        /// Provider to execute
        /// </summary>
        public ITraitsPipelineProvider Provider { get; set; }

        /// <summary>
        /// Additional settings needed to use this provider. For example an API Key.
        /// </summary>
        [DataMember]
        public Dictionary<string,string> ProviderSettings { get; set; }

    }
}
