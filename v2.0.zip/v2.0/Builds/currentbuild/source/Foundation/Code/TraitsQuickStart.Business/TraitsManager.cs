﻿/********************************************************************************
 * Traits Business Library 
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitsQuickStart.Business
{
    using TraitsQuickStart.Data;
    using DiagnosticsQuickStart.Business;
    using System.Collections.Generic;
    using System;
    using System.Linq;

    /// <summary>
    /// Base implemention of all Data Reader Providers
    /// </summary>
    public class TraitsManager
    {
        /// <summary>
        /// Object To Store Status
        /// </summary>
        public IEventLog Status { get; set; }

        /// <summary>
        /// Get traits from the give source
        /// </summary>
        /// <param name="sourceType">Type of source to get traits from eg. STRING, FILE</param>
        /// <param name="connectionString">Determines where to get traits</param>
        /// <returns></returns>
        public ITraits GetTraits(string sourceType, string connectionString)
        {
            ITraitsDataReader traitsReader = null;

            switch (sourceType.ToUpperInvariant())
            {
                case "FILE":
                    if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("ERROR: connectionString is required to load traits");

                    traitsReader = new FileTraitsProvider()
                    {
                        ConnectionString = connectionString,
                        Status = Status
                    };

                    break;
                default:

                    if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("ERROR: connectionString is required to load traits");

                    traitsReader = new StringTraitsProvider()
                    {
                        ConnectionString = connectionString,
                        Status = Status
                    };
                    break;
            }

            if (traitsReader.LoadTraits() == false) return null;

            return traitsReader.Traits;
        }

        /// <summary>
        /// Save traits to the give source
        /// </summary>
        /// <param name="sourceType">Type of source to get traits from eg. STRING, FILE</param>
        /// <param name="connectionString">Determines where to get traits</param>
        /// <returns></returns>
        public bool SaveTraits(string sourceType, string connectionString, ITraits traits)
        {
            ITraitsDataWriter traitsWriter = null;

            switch (sourceType.ToUpperInvariant())
            {
                case "FILE":
                    traitsWriter = new FileTraitsProvider();
                    break;
                default:
                    traitsWriter = new StringTraitsProvider();
                    break;
            }

            traitsWriter.ConnectionString = connectionString;
            traitsWriter.Traits = traits;

            return traitsWriter.SaveTraits();
        }

        /// <summary>
        /// Gets all the variable traits from the traits pairs
        /// </summary>
        /// <param name="traits">Dain's traits</param>
        /// <returns></returns>
        public Dictionary<string, string> GetVariableTraits(ITraits traits)
        {
            if (traits == null) throw new ArgumentNullException("ERROR: traits must be passed in");

            var results = new Dictionary<string, string>();
            foreach(var trait in traits.TraitPairs.Where(t => t.Key.StartsWith("[[")))
            {
                results.Add(trait.Key, trait.Value);
            }

            return results;
        }

        /// <summary>
        /// Expand variables in the trait value
        /// </summary>
        /// <param name="traits">List of Traits</param>
        /// <param name="traitValue">The value of the trait</param>
        /// <returns></returns>
        public string ApplyTrait(ITraits traits, string traitValue)
        {
            if (traits == null) throw new ArgumentNullException("ERROR: traits must be passed in");

            // Create a copy of the trait that we will apply
            var appliedTrait = traitValue;

            // Get all the trait variables
            var variables = GetVariableTraits(traits);
            if (appliedTrait.Contains("[["))
            {
                foreach (var variable in variables)
                {
                    appliedTrait = appliedTrait.Replace(variable.Key, variable.Value);
                }
            }

            // if it still contains variables try a second pass
            if (appliedTrait.Contains("[["))
            {
                foreach (var variable in variables)
                {
                    appliedTrait = appliedTrait.Replace(variable.Key, variable.Value);
                }
            }

            // if it still contains variables try a second pass
            if (appliedTrait.Contains("[["))
            {
                throw new NotImplementedException("ERROR: triple nested variables are not currently supported.");
            }

            return appliedTrait;
        }
    }
}
