﻿/********************************************************************************
 * CSHARP Traits Data Object Library 
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TraitsQuickStart.Data
{
    using DiagnosticsQuickStart.Business;

    /// <summary>
    /// Interface implemented by all traits Data Writer
    /// </summary>
    public interface ITraitsDataWriter
    {
        /// <summary>
        /// Object To Store Status
        /// </summary>
        IEventLog Status { get; set; }

        /// <summary>
        /// Settings and configuration
        /// </summary>
        ITraits Traits { get; set; }

        /// <summary>
        /// Information needed to connect to traits data source
        /// </summary>
        string ConnectionString { get; set; }

        /// <summary>
        /// Save Traits to the given location
        /// </summary>
        /// <returns></returns>
        bool SaveTraits();
    }
}
