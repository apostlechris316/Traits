
namespace TestTraitsQuickStartBusiness
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using TraitsQuickStart.Business;

    [TestClass]
    public class TestFileTraitsProvider
    {
        /// <summary>
        /// Test file type source valid traits JSON in connection string
        /// </summary>
        [TestMethod]
        public void TestGetTraitsFileProviderValid()
        {
            var traitsFilePath = "c:\\sampletraitsv2.json";
            var traitsProvider = new FileTraitsProvider()
            {
                ConnectionString = traitsFilePath
            };
            Assert.IsTrue(traitsProvider.LoadTraits());
            Assert.IsNotNull(traitsProvider.Traits);
            Assert.IsNotNull(traitsProvider.Traits.TraitPairs);
            Assert.IsTrue(traitsProvider.Traits.Version == "2.0");
            Assert.IsTrue(traitsProvider.Traits.TraitPairs.ContainsKey("Test_Trait_Key_1"));
        }
    }
}
