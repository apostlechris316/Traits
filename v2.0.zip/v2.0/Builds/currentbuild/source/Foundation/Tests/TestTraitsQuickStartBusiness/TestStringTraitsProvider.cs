namespace TestTraitsQuickStartBusiness
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using TraitsQuickStart.Business;

    [TestClass]
    public class TestStringTraitsProvider
    {
        /// <summary>
        /// Test string type source valid traits JSON in connection string
        /// </summary>
        [TestMethod]
        public void TestGetTraitsStringProviderValid()
        {
            var traitsJson = "{\"TraitPairs\":[{\"Key\":\"Test_Trait_Key_1\",\"Value\":\"Test_Trait_Value_1\"},{\"Key\":\"Test_Trait_Key_2\",\"Value\":\"Test_Trait_Value_2\"},{\"Key\":\"Test_Trait_Key_3\",\"Value\":\"Test_Trait_Value_3\"},{\"Key\":\"Test_Trait_Key_4\",\"Value\":\"Test_Trait_Value_4\"},{\"Key\":\"Test_Trait_Key_5\",\"Value\":\"Test_Trait_Value_5\"},{\"Key\":\"Test_Trait_Key_6\",\"Value\":\"Test_Trait_Value_6\"},{\"Key\":\"Test_Trait_Key_7\",\"Value\":\"Test_Trait_Value_6\"},{\"Key\":\"Test_Trait_Key_8\",\"Value\":\"Test_Trait_Value_7\"},{\"Key\":\"Test_Trait_Key_9\",\"Value\":\"Test_Trait_Value_8\"},{\"Key\":\"Test_Trait_Key_10\",\"Value\":\"Test_Trait_Value_10\"}],\"Version\":\"2.0\"}";
            var traitsProvider = new StringTraitsProvider()
            {
                ConnectionString = traitsJson
            };
            Assert.IsTrue(traitsProvider.LoadTraits());
            Assert.IsNotNull(traitsProvider.Traits);
            Assert.IsNotNull(traitsProvider.Traits.TraitPairs);
            Assert.IsTrue(traitsProvider.Traits.Version == "2.0");
            Assert.IsTrue(traitsProvider.Traits.TraitPairs.ContainsKey("Test_Trait_Key_1"));
        }
    }
}
