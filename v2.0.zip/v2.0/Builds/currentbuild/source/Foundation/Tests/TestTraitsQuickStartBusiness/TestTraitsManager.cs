
namespace TestTraitsQuickStartBusiness
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using TraitsQuickStart.Business;

    [TestClass]
    public class TestTraitsManger
    {
        /// <summary>
        /// Test if no source passed to traits
        /// </summary>
        [TestMethod]
        public void TestGetTraitsEmptySource()
        {
            var traitsManager = new TraitsManager();
            Assert.ThrowsException<ArgumentNullException>(() => traitsManager.GetTraits(string.Empty, string.Empty));
        }

        #region String Provider Related Tests

        /// <summary>
        /// Test string type source valid traits JSON in connection string
        /// </summary>
        [TestMethod]
        public void TestGetTraitsStringSourceValid()
        {
            var traitsJson = "{\"TraitPairs\":[{\"Key\":\"Test_Trait_Key_1\",\"Value\":\"Test_Trait_Value_1\"},{\"Key\":\"Test_Trait_Key_2\",\"Value\":\"Test_Trait_Value_2\"},{\"Key\":\"Test_Trait_Key_3\",\"Value\":\"Test_Trait_Value_3\"},{\"Key\":\"Test_Trait_Key_4\",\"Value\":\"Test_Trait_Value_4\"},{\"Key\":\"Test_Trait_Key_5\",\"Value\":\"Test_Trait_Value_5\"},{\"Key\":\"Test_Trait_Key_6\",\"Value\":\"Test_Trait_Value_6\"},{\"Key\":\"Test_Trait_Key_7\",\"Value\":\"Test_Trait_Value_6\"},{\"Key\":\"Test_Trait_Key_8\",\"Value\":\"Test_Trait_Value_7\"},{\"Key\":\"Test_Trait_Key_9\",\"Value\":\"Test_Trait_Value_8\"},{\"Key\":\"Test_Trait_Key_10\",\"Value\":\"Test_Trait_Value_10\"}],\"Version\":\"2.0\"}";
            var traitsManager = new TraitsManager();
            var traits = traitsManager.GetTraits(string.Empty, traitsJson);
            if(traits != null) traitsManager.GetTraits("STRING", traitsJson);

            Assert.IsNotNull(traits);
            Assert.IsNotNull(traits.TraitPairs);
            Assert.IsTrue(traits.Version == "2.0");
            Assert.IsTrue(traits.TraitPairs.ContainsKey("Test_Trait_Key_1"));
        }

        #endregion

        #region File Provider Related Tests

        /// <summary>
        /// Test file type source no filepath passed in
        /// </summary>
        [TestMethod]
        public void TestGetTraitsFileSourceEmptyConnectionString()
        {
            var traitsManager = new TraitsManager();
            Assert.ThrowsException<ArgumentNullException>(() => traitsManager.GetTraits("FILE", string.Empty));
        }

        /// <summary>
        /// Test file type source file does not exist
        /// </summary>
        [TestMethod]
        public void TestGetTraitsFileSourceConnectionStringFileNotFound()
        {
            var traitsRelativeFilePath = "C:\\traitsnotfound.json";
            var traitsManager = new TraitsManager();
            Assert.ThrowsException<FileNotFoundException>(() => traitsManager.GetTraits("FILE", traitsRelativeFilePath));
        }

        /// <summary>
        /// Test file type source file valid traits file absolute path
        /// </summary>
        [TestMethod]
        public void TestGetTraitsFileSourceAbsoultePathValid()
        {
            var traitsRelativeFilePath = "c:\\sampletraitsv2.json";
            var traitsManager = new TraitsManager();
            var traits = traitsManager.GetTraits("FILE", traitsRelativeFilePath);

            Assert.IsNotNull(traits);
            Assert.IsNotNull(traits.TraitPairs);
            Assert.IsTrue(traits.Version == "2.0");
            Assert.IsTrue(traits.TraitPairs.ContainsKey("Test_Trait_Key_1"));
        }

        /// <summary>
        /// Test file type source file valid traits file relative path
        /// </summary>
        [TestMethod]
        public void TestGetTraitsFileSourceRelativePathValid()
        {
            var traitsRelativeFilePath = "..\\..\\..\\..\\..\\..\\data\\test_traits.json";
            var traitsManager = new TraitsManager();
            var traits = traitsManager.GetTraits("FILE", traitsRelativeFilePath);
            Assert.IsNotNull(traits);
            Assert.IsNotNull(traits.TraitPairs);
            Assert.IsTrue(traits.Version == "2.0");
            Assert.IsTrue(traits.TraitPairs.ContainsKey("Test_Trait_Key_1"));
        }

        #endregion
    }
}
