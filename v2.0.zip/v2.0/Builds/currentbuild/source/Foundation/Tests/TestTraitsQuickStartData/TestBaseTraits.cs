using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestTraitsQuickStartData
{
    [TestClass]
    public class TestBaseTraits
    {
        [TestMethod]
        public void TestBaseTraits1()
        {
        }
    }
}
