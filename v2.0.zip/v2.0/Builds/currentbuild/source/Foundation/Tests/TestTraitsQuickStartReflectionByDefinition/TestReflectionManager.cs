using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestTraitsQuickStartReflectionByDefinition
{
    [TestClass]
    public class TestReflectionManager
    {
        [TestMethod]
        public void TestCreateReflectionDefinition()
        {
        }
    }
}
