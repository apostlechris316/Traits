using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestsTraitsQuickStartProvidersByReflection
{
    [TestClass]
    public class TestProviderRefelctionManager
    {
        [TestMethod]
        public void TestGetAllProviderNamesOfObjectType()
        {
        }
    }
}
