﻿
namespace TraitsQuickStart.Features.Pipelines.Business
{
    using DiagnosticsQuickStart.Business;
    using System;
    using System.Collections.Generic;
    using TraitsQuickStart.Data;
    using TraitsQuickStart.Features.Pipelines.Data;
    using TraitsQuickStart.ReflectionByDefinition;

    /// <summary>
    /// Manages loading and saving pipelines to the proper location by provider loaded by Reflection Definition
    /// </summary>
    public class ReflectionDefinitionEnabledTraitsPipelineManager : IReflectionDefinitionTraitsPipelineManager
    {
        /// <summary>
        /// The object to log warnings and errors to
        /// </summary>
        public IEventLog Status { get; set; }

        /// <summary>
        /// Settings that affect the behavior of the pipeline
        /// </summary>
        public ITraits Traits { get; set; }

        /// <summary>
        /// The provider folder of the Langauge Detection Providers
        /// </summary>
        public string ProviderRootPath { get; set; }

        /// <summary>
        /// Full path (or relative path to current directory) to folder containing the reflection definitions
        /// </summary>
        public string ReflectionDefinitionFolder { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public ITraitsPipeline Pipeline { get; set; }

        /// <summary>
        /// Type of object used for serialization.
        /// </summary>
        public Type PipelineObjectType { get; set; }

        #region LoadTraitsPipeline Related

        /// <summary>
        /// Loads the Traits Pipeline using the default pipeline source type and connnection string from Traits
        /// </summary>
        /// <param name="pipelineTypePrefix">This is used in the traits call to prefix the pipeline settings eg. LANGUAGE</param>
        /// <returns></returns>
        public virtual bool LoadTraitsPipeline(string pipelineTypePrefix)
        {
            return LoadTraitsPipeline(pipelineTypePrefix, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pipelineTypePrefix"></param>
        /// <param name="overridePipelineSettings"></param>
        /// <returns></returns>
        public virtual bool LoadTraitsPipeline(string pipelineTypePrefix, Dictionary<string, string> overridePipelineSettings)
        {
            if (overridePipelineSettings == null && Traits == null) throw new ArgumentNullException("ERROR: Either overridePipelineSettings needs to be passed in or Traits supplied for defaults");

            var pipelineSourceTypeFieldName = pipelineTypePrefix + "_PIPELINE_SOURCE_TYPE";
            var pipelineConnectionStringFieldName = pipelineTypePrefix + "_PIPELINE_CONNECTION_STRING";

            var pipelineSourceType = (overridePipelineSettings != null)
                    ? overridePipelineSettings.ContainsKey(pipelineSourceTypeFieldName)
                        ? overridePipelineSettings[pipelineSourceTypeFieldName]
                        : Traits.TraitPairs.ContainsKey(pipelineSourceTypeFieldName)
                            ? Traits.TraitPairs[pipelineSourceTypeFieldName]
                            : throw new ArgumentNullException("ERROR: " + pipelineSourceTypeFieldName + " is required to load traits pipeline")
                    : Traits.TraitPairs.ContainsKey(pipelineSourceTypeFieldName)
                        ? Traits.TraitPairs[pipelineSourceTypeFieldName]
                        : throw new ArgumentNullException("ERROR: " + pipelineSourceTypeFieldName + " is required to load traits pipeline");

            var pipelineConnectionString = (overridePipelineSettings != null)
                    ? overridePipelineSettings.ContainsKey(pipelineConnectionStringFieldName)
                        ? overridePipelineSettings[pipelineConnectionStringFieldName]
                        : Traits.TraitPairs.ContainsKey(pipelineConnectionStringFieldName)
                            ? Traits.TraitPairs[pipelineConnectionStringFieldName]
                            : throw new ArgumentNullException("ERROR: " + pipelineConnectionStringFieldName + " is required to load traits pipeline")
                    : Traits.TraitPairs.ContainsKey(pipelineConnectionStringFieldName)
                        ? Traits.TraitPairs[pipelineConnectionStringFieldName]
                        : throw new ArgumentNullException("ERROR: " + pipelineConnectionStringFieldName + " is required to load traits pipeline");

            return LoadTraitsPipeline(pipelineTypePrefix, pipelineSourceType, pipelineConnectionString, overridePipelineSettings);
        }

        /// <summary>
        /// Loads the Traits Pipeline
        /// </summary>
        /// <param name="pipelineTypePrefix"></param>
        /// <param name="pipelineSourceType"></param>
        /// <param name="connectionString"></param>
        /// <param name="overridePipelineSettings"></param>
        /// <returns></returns>
        public virtual bool LoadTraitsPipeline(string pipelineTypePrefix, string pipelineStorageProviderSourceType, string pipelineStorageProviderConnectionString, Dictionary<string, string> overridePipelineSettings)
        {
            var pipelineSettings = new Dictionary<string, string>();

            if (overridePipelineSettings != null)
            {
                // Copy all the pairs in if they are not overridden by the overridePipelineSettings
                foreach (var setting in overridePipelineSettings)
                {
                    if (pipelineSettings.ContainsKey(setting.Key) == false) pipelineSettings.Add(setting.Key, setting.Value);
                }
            }

            // Copy all the pairs in if they are not overridden by the overridePipelineSettings
            if (Traits != null)
            {
                if (Traits.TraitPairs != null)
                {
                    foreach (var traitPair in Traits.TraitPairs)
                    {
                        if (pipelineSettings.ContainsKey(traitPair.Key) == false) pipelineSettings.Add(traitPair.Key, traitPair.Value);
                    }
                }
            }

            // Use reflection to load the pipeline storage provider
            var reflectionManager = new ReflectionManager()
            {
                 ProviderRootFolder = ProviderRootPath,
                 ReflectionDefinitionFolder = ReflectionDefinitionFolder
            };

            var traitsPipelineReader = reflectionManager.LoadObject("PROVIDER_PIPELINE_STORAGE_PROVIDER_" + pipelineStorageProviderSourceType) as ITraitsPipelineReader;
            traitsPipelineReader.ConnectionString = pipelineStorageProviderConnectionString;
            traitsPipelineReader.TraitsPipelineType = PipelineObjectType;
            Pipeline = traitsPipelineReader.LoadTraitsPipeline();

            // Ensure all providers have the provider settings
            foreach (var step in Pipeline.PipelineSteps)
            {
                // if provider is not loaded then we need to load it
                if (step.Provider == null)
                {
                    if (string.IsNullOrEmpty(step.ProviderName)) throw new NullReferenceException("Pipeline Steps must have a provider name");
                    step.Provider = reflectionManager.LoadObject("PROVIDER_" + pipelineTypePrefix + "_PROVIDER" + "_" + step.ProviderName) as ITraitsPipelineProvider;
                }

                // Ensure each provider has traits
                if (step.Provider.ProviderSettings == null) step.Provider.ProviderSettings = new Dictionary<string, string>();

                // if traits are supplied ensure they are passed to the provider
                if (Traits != null && Traits.TraitPairs != null)
                {
                    foreach (var traitPair in Traits.TraitPairs)
                    {
                        step.Provider.ProviderSettings.Add(traitPair.Key, traitPair.Value);
                    }
                }
            }

            return true;
        }

        #endregion

        #region SaveTratisPipeline Related

        /// <summary>
        /// Saves the Traits Pipeline using the default pipeline source type and connnection string from Traits
        /// </summary>
        /// <param name="pipelineTypePrefix">This is used in the traits call to prefix the pipeline settings eg. LANGUAGE</param>
        /// <returns></returns>
        public virtual bool SaveTraitsPipeline(string pipelineTypePrefix)
        {
            return SaveTraitsPipeline(pipelineTypePrefix, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pipelineTypePrefix"></param>
        /// <param name="overridePipelineSettings"></param>
        /// <returns></returns>
        public virtual bool SaveTraitsPipeline(string pipelineTypePrefix, Dictionary<string, string> overridePipelineSettings)
        {
            if (overridePipelineSettings == null && Traits == null) throw new ArgumentNullException("ERROR: Either overridePipelineSettings needs to be passed in or Traits supplied for defaults");

            var pipelineSourceTypeFieldName = pipelineTypePrefix + "_PIPELINE_SOURCE_TYPE";
            var pipelineConnectionStringFieldName = pipelineTypePrefix + "_PIPELINE_CONNECTION_STRING";

            var pipelineSourceType = (overridePipelineSettings != null)
                    ? overridePipelineSettings.ContainsKey(pipelineSourceTypeFieldName)
                        ? overridePipelineSettings[pipelineSourceTypeFieldName]
                        : Traits.TraitPairs.ContainsKey(pipelineSourceTypeFieldName)
                            ? Traits.TraitPairs[pipelineSourceTypeFieldName]
                            : throw new ArgumentNullException("ERROR: " + pipelineSourceTypeFieldName + " is required to load traits pipeline")
                    : Traits.TraitPairs.ContainsKey(pipelineSourceTypeFieldName)
                        ? Traits.TraitPairs[pipelineSourceTypeFieldName]
                        : throw new ArgumentNullException("ERROR: " + pipelineSourceTypeFieldName + " is required to load traits pipeline");

            var pipelineConnectionString = (overridePipelineSettings != null)
                    ? overridePipelineSettings.ContainsKey(pipelineConnectionStringFieldName)
                        ? overridePipelineSettings[pipelineConnectionStringFieldName]
                        : Traits.TraitPairs.ContainsKey(pipelineConnectionStringFieldName)
                            ? Traits.TraitPairs[pipelineConnectionStringFieldName]
                            : throw new ArgumentNullException("ERROR: " + pipelineConnectionStringFieldName + " is required to load traits pipeline")
                    : Traits.TraitPairs.ContainsKey(pipelineConnectionStringFieldName)
                        ? Traits.TraitPairs[pipelineConnectionStringFieldName]
                        : throw new ArgumentNullException("ERROR: " + pipelineConnectionStringFieldName + " is required to load traits pipeline");

            return SaveTraitsPipeline(pipelineTypePrefix, pipelineSourceType, pipelineConnectionString, overridePipelineSettings);
        }

        /// <summary>
        /// Save the Traits Pipeline
        /// </summary>
        /// <param name="pipelineTypePrefix"></param>
        /// <param name="pipelineSourceType"></param>
        /// <param name="connectionString"></param>
        /// <param name="overridePipelineSettings"></param>
        /// <returns></returns>
        public virtual bool SaveTraitsPipeline(string pipelineTypePrefix, string pipelineSourceType, string connectionString, Dictionary<string, string> overridePipelineSettings)
        {
            if (string.IsNullOrEmpty(ProviderRootPath)) throw new ArgumentNullException("ERROR: providerRootPath is required");

            var pipelineSettings = new Dictionary<string, string>();

            if (overridePipelineSettings != null)
            {
                // Copy all the pairs in if they are not overridden by the overridePipelineSettings
                foreach (var setting in overridePipelineSettings)
                {
                    if (pipelineSettings.ContainsKey(setting.Key) == false) pipelineSettings.Add(setting.Key, setting.Value);
                }
            }

            // Use reflection to load the pipeline storage provider
            var reflectionManager = new ReflectionManager()
            {
                ReflectionDefinitionFolder = ReflectionDefinitionFolder,
                ProviderRootFolder = ProviderRootPath
            };
            var traitsPipelineWriter = reflectionManager.LoadObject("PROVIDER_PIPELINE_STORAGE_PROVIDER_" + pipelineSourceType) as ITraitsPipelineWriter;
            traitsPipelineWriter.ConnectionString = connectionString;

            return traitsPipelineWriter.SaveTraitsPipeline(Pipeline);
        }

        /// <summary>
        /// Save the Traits Pipeline
        /// </summary>
        /// <param name="pipelineSourceType"></param>
        /// <param name="connectionString"></param>
        /// <param name="pipelineType"></param>
        /// <param name="overridePipelineSettings"></param>
        /// <returns></returns>
        public virtual bool SaveTraitsPipeline(string pipelineTypePrefix, string pipelineSourceType, string connectionString, Type traitsPipelineType, Dictionary<string, string> overridePipelineSettings)
        {
            var pipelineSettings = new Dictionary<string, string>();

            if (overridePipelineSettings != null)
            {
                // Copy all the pairs in if they are not overridden by the overridePipelineSettings
                foreach (var setting in overridePipelineSettings)
                {
                    if (pipelineSettings.ContainsKey(setting.Key) == false) pipelineSettings.Add(setting.Key, setting.Value);
                }
            }

            // Use reflection to load the pipeline storage provider
            var reflectionManager = new ReflectionManager();
            var traitsPipelineWriter = reflectionManager.LoadObject("PROVIDER_PIPELINE_STORAGE_PROVIDER_" + pipelineSourceType) as ITraitsPipelineWriter;
            traitsPipelineWriter.ConnectionString = connectionString;

            return traitsPipelineWriter.SaveTraitsPipeline(Pipeline);
        }

        #endregion

        /// <summary>
        /// Executes all the relevant steps in the traits pipeline
        /// </summary>
        /// <returns></returns>
        public virtual bool ExecuteTraitsPipeline()
        {
            throw new NotImplementedException("ERROR: The base pipeline manager does not implment execute");
        }
    }
}
